<?php

namespace App\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;

//class Admin extends Model
class Admin extends Authenticatable
{
   

}
