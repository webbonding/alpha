<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Cmspage extends Model {

    protected $table = 'cms_page';

}
