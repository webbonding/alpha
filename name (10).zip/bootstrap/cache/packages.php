<?php return array (
  'androidneha/laravel-msg91' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Msg91\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Msg91' => 'Laravel\\Msg91\\Facade',
    ),
  ),
  'craftsys/msg91-laravel' => 
  array (
    'aliases' => 
    array (
      'Msg91' => 'Craftsys\\Msg91\\Facade\\Msg91',
    ),
    'providers' => 
    array (
      0 => 'Craftsys\\Msg91\\Msg91LaravelServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
  ),
  'torann/laravel-meta-tags' => 
  array (
    'providers' => 
    array (
      0 => 'Torann\\LaravelMetaTags\\MetaTagsServiceProvider',
    ),
    'aliases' => 
    array (
      'MetaTag' => 'Torann\\LaravelMetaTags\\Facades\\MetaTag',
    ),
  ),
  'yajra/laravel-datatables-oracle' => 
  array (
    'providers' => 
    array (
      0 => 'Yajra\\DataTables\\DataTablesServiceProvider',
    ),
    'aliases' => 
    array (
      'DataTables' => 'Yajra\\DataTables\\Facades\\DataTables',
    ),
  ),
);